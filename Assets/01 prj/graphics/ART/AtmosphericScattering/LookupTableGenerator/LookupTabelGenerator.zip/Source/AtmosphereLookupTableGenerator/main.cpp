using namespace std;

#include <windows.h>
#include <iostream>
#include <string>
#include <FreeImage.h>

struct Vector2
{
	float x, y;
};

bool SphereRayHit(Vector2& origin, Vector2& dir, const float& radius, float &enter, float &exit)
{
	float tc = origin.x * dir.x + origin.y * dir.y;
	float o2 = origin.x * origin.x + origin.y * origin.y;
	float d2 = o2 - tc*tc;
	float r2 = radius * radius;
	if (d2 > r2) return false;
	float dt = sqrt(r2 - d2);
	enter = -tc - dt;
	exit = -tc + dt;
	return true;
}

string ToString(float& f)
{
	string s = to_string(f);
	s.erase(s.find_last_not_of('0') + 1);
	if (s.back() == '.')
		s.pop_back();
	return s;
}

string ToString(int& i)
{
	string s = to_string(i);
	s.erase(s.find_last_not_of('0') + 1);
	if (s.back() == '.')
		s.pop_back();
	return s;
}

int main()
{
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	int resolution, stepCount;
	float Hr, Hm, scale;
	cout << "Resolution: ";
	cin >> resolution;
	cout << "Step Count: ";
	cin >> stepCount;
	cout << "Atmosphere Scale: ";
	cin >> scale;
	cout << "Rayleigh Dencity: ";
	cin >> Hr;
	cout << "Mei Dencity: ";
	cin >> Hm;

	cout << "Generating lookup table with settings..." << endl;
	FIBITMAP* bitmap = FreeImage_AllocateT(FIT_RGBAF, resolution, resolution);
	FIRGBAF* bits;
	FIRGBAF* newBits = new FIRGBAF[resolution];
	float planetRadius = 1.0f / scale;
	float sin = 0, sout = 0;
	float Sr = 0, Sm = 0;
	float lastPercent = 0;
	const int percentIncrement = 1;
	DWORD count;
	Vector2 right = { 1,0 };
	for (int y = 0; y < resolution; y++)
	{
		bits = (FIRGBAF*)FreeImage_GetScanLine(bitmap, y);
		
		for (int x = 0; x < resolution; x++)
		{
			float dot = ((float)x / resolution) * 2.0f - 1.0f;
			float heightRatio = (float)y / resolution;
			float Dr = exp(-heightRatio / Hr);
			float Dm = exp(-heightRatio / Hm);
			Vector2 direction = { dot, sqrt(1 - dot * dot) };
			float length = planetRadius + heightRatio * (1.0f - planetRadius);
			Vector2 position = { direction.x * length,direction.y * length };

			bool sphereHit = SphereRayHit(position, right, 1, sin, sout);
			if (!sphereHit)
			{
				newBits[x] = { 0,0,0,0 };
				continue;
			}
			float t = sout;
			Sr = 0.0f;
			Sm = 0.0f;
			float stepSize = t / stepCount;
			Vector2 current = { position.x + stepSize * 0.5f, position.y };
			for (int i = 0; i < stepCount; i++)
			{
				float h = (sqrt(current.x * current.x + current.y * current.y) - planetRadius) / (1.0f - planetRadius);
				Sr += exp(-h / Hr) * stepSize;
				Sm += exp(-h / Hm) * stepSize;
				current = { current.x + stepSize,current.y };
			}
			newBits[x] = { Sr, Dr, Sm, Dm };
		}
		memcpy(bits, newBits, sizeof(FIRGBAF)*resolution);
		float percent = floor((((float)y / (float)resolution) * 100) / percentIncrement) * percentIncrement;
		if (percent != lastPercent)
		{
			FillConsoleOutputCharacter(hStdOut, ' ', 32, { 0,6 }, &count);
			SetConsoleCursorPosition(hStdOut, { 0,6 });

			cout << percent << "% Complete...";
			lastPercent = percent;
		}
	}
	FillConsoleOutputCharacter(hStdOut, ' ', 32, { 0,6 }, &count);
	SetConsoleCursorPosition(hStdOut, { 0,6 });

	cout << "100% Complete..." << endl;
	string fileName = string("Atmosphere(Hr#" + ToString(Hr) + ",Hm#" + ToString(Hm) + ",S#" + ToString(scale) + ",SC#" + ToString(stepCount) + ",RES#"+ ToString(resolution) + ").exr");
	if (FreeImage_Save(FIF_EXR, bitmap, fileName.c_str(), 0))
		cout << "Saved to \"" << fileName.c_str() << "\"" << endl;
	else
		cout << "Failed to save image!" << endl;
	delete[] newBits;
	system("pause");
	return 0;
}